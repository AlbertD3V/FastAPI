import sqlite3

conexao = sqlite3.connect('dados_alunos.bd')
cursor = conexao.cursor()

#cursor.execute("INSERT INTO alunos VALUES (9,'xavier','ads',56)")
#conexao.commit()

cursor.execute("SELECT * FROM alunos")
data = cursor.fetchall()
print(data)

conexao.close()
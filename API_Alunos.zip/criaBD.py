import sqlite3

conexao = sqlite3.connect('dados_alunos.bd')
bd = conexao.cursor()
cmdsql = '''
create table if not exists alunos (
  id int not null primary key,
  nome text not null,
  curso text null,
  idade int null
);
'''
bd.execute(cmdsql)
cmdsql = "insert into alunos values(1,'Maria','eng',25);"
bd.execute(cmdsql)
cmdsql = "insert into alunos values(2,'Pedro','med',23);"
bd.execute(cmdsql)
cmdsql = "insert into alunos values(3,'Joana','ped',28);"
bd.execute(cmdsql)
cmdsql = "insert into alunos values(4,'Marcos','ads',30);"
bd.execute(cmdsql)
cmdsql = "insert into alunos values(5,'Sofia','dir',21);"
bd.execute(cmdsql)
cmdsql = "insert into alunos values(6,'Carlos','mat',31);"
bd.execute(cmdsql)
conexao.commit()
conexao.close()
from flask import Flask, jsonify
import sqlite3

# ------------------ API ----------------------
app = Flask(__name__)


# Criando as rotas (entry-points) da API
@app.route('/')
def home():
  return 'A API ALUNOS está no ar'


@app.route('/turma')
def pesq_todos():
  conexao = sqlite3.connect("dados_alunos.bd")
  cursor = conexao.cursor()
  cmdsql = "SELECT id,nome FROM alunos;"
  cursor.execute(cmdsql)
  resposta = {}
  for aluno in cursor.fetchall():
    resposta[aluno[0]] = aluno[1]
  conexao.close()
  return jsonify(resposta)


@app.route('/aluno/<id_aluno>')
def pesq_um_aluno(id_aluno):
  conexao = sqlite3.connect("dados_alunos.bd")
  cursor = conexao.cursor()
  cmdsql = f"select * from alunos where id = {id_aluno}"
  cursor.execute(cmdsql)
  aluno = cursor.fetchone()
  resposta = {
    "id": aluno[0],
    "nome": aluno[1],
    "curso": aluno[2],
    "idade": aluno[3]
  }
  conexao.close()
  return jsonify(resposta)


@app.route('/curso/<curso>')
def pesq_curso(curso):
  conexao = sqlite3.connect("dados_alunos.bd")
  cursor = conexao.cursor()
  cmdsql = f"SELECT id,nome,idade FROM alunos WHERE curso = '{curso}'"
  cursor.execute(cmdsql)
  resposta = {}
  for aluno in cursor.fetchall():
    resposta[aluno[0]] = {"nome": aluno[1], "idade": aluno[2]}
  conexao.close()
  return jsonify(resposta)


# Execução da API
app.run(host='0.0.0.0')

import requests,json

print('''
    Opções:
    1. Exibe todos os animais
    2. Recupera nome do bicho pelo tipo
    3. Recupera tipo do bicho pelo nome
    4. Inclui novo bicho
    ''')
pesq = input('Informe a opção desejada: ')

if pesq == '1':
  link = 'https://apibichos.eduardoxavier3.repl.co/tudo'
  requisicao = requests.get(link)
  print('-----[Pesquisa TODOS os bichos]-----')
  print(requisicao.json())
elif pesq == '2':
  tipo = input ('Tipo? ')
  link = f'https://apibichos.eduardoxavier3.repl.co/consultar?tipo={tipo}'
  requisicao = requests.get(link)
  print(f'-----[Pesquisa pelo tipo "{tipo}"]-----')
  print(requisicao.json())
elif pesq == '3':
  nome = input ('Nome? ')
  link = f'https://apibichos.eduardoxavier3.repl.co/consultar?nome={nome}'
  requisicao = requests.get(link)
  print(f'-----[Pesquisa pelo nome "{nome}"]-----')
  print(requisicao.json())
elif pesq == '4':
  tipo = input('Tipo do bicho? ')
  nome = input('Nome do bicho? ')
  info = {'tipo':tipo,'nome':nome}
  print(info,type(info))
  link = f'https://apibichos.eduardoxavier3.repl.co/inc_post'
  requisicao = requests.post(link,json=info)
  print(f'-----[Novo bicho incluído]-----')
  print(requisicao.json())
#  print(requisicao.json())


print('Fim do cliente')
3
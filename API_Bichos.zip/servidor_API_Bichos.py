from flask import Flask, request
# ----------------------
# DADOS
zoo = {
  'leao': 'simba',
  'girafa': 'pescoço',
  'hipopotamo': 'xavier',
  'macaco': 'chita',
}
# ----------------------

app = Flask(__name__)


@app.route('/')
def home():
  return 'API Bichos funcionando'


@app.route('/tipo/<tipo>')
def pesq_tipo(tipo=None):
  return f'O nome do bicho é {zoo[tipo]}'


@app.route('/nome/<nm>')
def pesq_nome(nm=None):
  resposta = 'Não identificado'
  for tipo, nome in zoo.items():
    if nome == nm:
      resposta = tipo
  return resposta


@app.route('/qtd')
def pesq_qtd():
  return f'O zoológico tem {len(zoo)} bichos'


@app.route('/tudo')
def pesq_tudo():
  return zoo


@app.route('/consultar')
def consultar_dados():
  # se a chave não existir retorna 'None'
  tipobicho = request.args.get('tipo')
  nomebicho = request.args.get('nome')
  if tipobicho != None:
    if tipobicho in zoo.keys():
      resposta = {tipobicho: zoo[tipobicho]}
    else:
      resposta = {tipobicho: 'não encontrado'}
    return resposta
  elif nomebicho != None:
    resposta = {'não encontrado': nomebicho}
    for tipo, nome in zoo.items():
      if nome == nomebicho:
        resposta = {tipo: nome}
    return resposta
  else:
    resposta = {'bicho': 'não encontrado'}
    return resposta


@app.route('/inc_get', methods=['GET'])
def inc_dados():
  tipobicho = request.args.get('tipo')
  nomebicho = request.args.get('nome')
  zoo[tipobicho] = nomebicho
  resposta = {'inclusao': 'ok usando GET'}
  return resposta


@app.route('/inc_post', methods=['POST'])
def inc_post():
  dados = request.get_json()
  tipobicho = dados['tipo']
  nomebicho = dados['nome']
  zoo[tipobicho] = nomebicho
  resposta = {'inclusao': 'ok usando POST'}
  return resposta


app.run(host='0.0.0.0')